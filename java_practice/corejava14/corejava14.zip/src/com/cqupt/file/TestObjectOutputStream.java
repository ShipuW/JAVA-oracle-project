package com.cqupt.file;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
public class TestObjectOutputStream {
	public static void main(String[] args) throws Exception {
		Student stu1 = new Student("zhangsan",18);
		Student stu2 = new Student("lisi",18);
		FileOutputStream fos = new FileOutputStream("stu.dat");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(stu1);
		oos.close();
	}
	

}
